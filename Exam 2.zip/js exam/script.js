

function randomNumber() {
    let input = document.getElementById('inp').value;
    let randomNum = 0;
    let array = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    let num = document.getElementById('answer');
    let data = "";
    
     for(i=0; i<input; i++){
     randomNum = Math.floor(Math.random()* array.length);
     data += array[randomNum];
     }
     num.innerHTML = data;
    //  console.log(randomNum);
}

